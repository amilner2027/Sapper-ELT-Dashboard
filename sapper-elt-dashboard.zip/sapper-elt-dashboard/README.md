# Sapper ELT Dashboard

A modern, executive-level fulfillment dashboard built with Next.js 14, TypeScript, and Tailwind CSS.

## 🚀 Features

- **Barbie Principle** - High-value client focus visualization
- **Current Challenges** - Real-time challenge tracking
- **Client Breakdown & Fulfillment** - Segmented performance metrics
- **Operations Health** - Team and SDR metrics at a glance
- **Calling Metrics** - Detailed outbound performance tracking
- **What Went Right/Improve** - Performance review section
- **One Thing Focus** - Priority goal tracking with progress
- **Execution Gameplan** - Strategic planning and action items
- **Edit Functionality** - Real-time data editing sidebar
- **Export PDF** - Print-ready formatting
- **Present Mode** - Fullscreen presentation capability

## 📦 Tech Stack

- **Framework:** Next.js 14 (App Router)
- **Language:** TypeScript
- **Styling:** Tailwind CSS
- **Icons:** Lucide React
- **Database Ready:** Supabase integration prepared

## 🛠️ Setup Instructions

### 1. Clone or Extract

```bash
# If you have this as a zip file, extract it first
unzip sapper-elt-dashboard.zip
cd sapper-elt-dashboard
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### 4. Build for Production

```bash
npm run build
npm start
```

## 🚀 Deploy to Vercel

### Option A: Deploy via Vercel Dashboard

1. Push this code to a GitHub repository
2. Go to [vercel.com](https://vercel.com)
3. Click "Import Project"
4. Select your GitHub repo
5. Click "Deploy"

### Option B: Deploy via Vercel CLI

```bash
npm install -g vercel
vercel
```

## 📁 Project Structure

```
sapper-elt-dashboard/
├── app/
│   ├── globals.css          # Global styles and Tailwind
│   ├── layout.tsx           # Root layout
│   └── page.tsx             # Main dashboard page
├── components/
│   ├── Header.tsx           # Navigation header
│   ├── BarbiePrinciple.tsx  # Barbie principle section
│   ├── CurrentChallenges.tsx
│   ├── ClientBreakdown.tsx
│   ├── OperationsHealth.tsx
│   ├── CallingMetrics.tsx
│   ├── WhatWentRight.tsx
│   ├── BarbieOneThing.tsx
│   ├── Gameplan.tsx
│   └── EditSidebar.tsx      # Edit panel
├── lib/
│   ├── types.ts             # TypeScript interfaces
│   └── defaultData.ts       # Default dashboard values
├── public/                  # Static assets
├── tailwind.config.js       # Tailwind configuration
├── tsconfig.json            # TypeScript configuration
└── package.json             # Dependencies
```

## 🎨 Customization

### Colors

Edit `tailwind.config.js` to change the brand colors:

```javascript
colors: {
  sapper: {
    navy: '#1E3A5F',      // Primary dark blue
    blue: '#3B82F6',      // Accent blue
    // ...
  },
  barbie: {
    pink: '#FF69B4',      // High-value client highlight
    // ...
  }
}
```

### Default Data

Edit `lib/defaultData.ts` to change the initial values that appear in the dashboard.

### Adding Sections

1. Create a new component in `components/`
2. Add the corresponding types in `lib/types.ts`
3. Add default values in `lib/defaultData.ts`
4. Import and render in `app/page.tsx`

## 🔌 Supabase Integration (Optional)

To add persistent storage:

1. Create a Supabase project at [supabase.com](https://supabase.com)
2. Create a `.env.local` file:

```env
NEXT_PUBLIC_SUPABASE_URL=your-project-url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
```

3. Create a `lib/supabase.ts` file:

```typescript
import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseKey)
```

## 📱 Responsive Design

The dashboard is fully responsive and works on:
- Desktop (1024px+)
- Tablet (768px - 1023px)  
- Mobile (< 768px)

## 🖨️ Print Support

Click "Export PDF" to print the dashboard. The header and edit buttons are automatically hidden in print view.

## 📝 License

MIT License - feel free to use and modify for your needs.

---

Built with ❤️ for Sapper Consulting
