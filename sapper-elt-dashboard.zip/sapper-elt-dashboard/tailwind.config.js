/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        // Sapper Brand Colors
        sapper: {
          navy: '#1E3A5F',
          'navy-dark': '#152942',
          'navy-light': '#2A4A73',
          blue: '#3B82F6',
          'blue-light': '#60A5FA',
          coral: '#FF6B6B',
          'coral-light': '#FF8A8A',
          orange: '#F59E0B',
          teal: '#14B8A6',
          green: '#10B981',
          red: '#EF4444',
        },
        // Barbie pink for high-value clients
        barbie: {
          pink: '#FF69B4',
          'pink-light': '#FFB6C1',
          'pink-dark': '#DB7093',
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
