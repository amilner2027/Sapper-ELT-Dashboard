// Dashboard data types

export interface OpenerMetrics {
  totalRevenue: string;
  ebitdaDollars: string;
  ebitdaPercent: string;
  retention: string;
  totalClients: number;
  growthInMonth: string;
}

export interface MonthRecap {
  toplineRevenue: string;
  // Add more fields as needed
}

export interface ClientSegment {
  name: string;
  color: string;
  numberOfClients: number;
  percentOfTotal?: string;
  appointmentGoal: number;
  totalAppointments: number;
  percentToGoal: string;
  under50: number;
  zeros: number;
}

export interface OperationsHealth {
  overallShowRate: string;
  sapperOutboundSDRs: number;
  strategicSDRs: number;
  totalPDMs: number;
  sdrsUnder15Appts: number;
}

export interface CallingMetrics {
  contactRate: string;
  pitchRate: string;
  closeRate: string;
  showRate: string;
  qualityScore: string;
  contractsOnPace: string;
  revenueClosed: string;
  averageDials: number;
  sdrsUnder15Appts: number;
}

export interface PerformanceReview {
  whatWentRight: string[];
  whereToImprove: string[];
}

export interface BarbieOneThing {
  headline: string;
  progress: number;
  whyThisMatters: string;
  owner: string;
  ownerInitial: string;
  successDefinition: string;
}

export interface CurrentChallenge {
  title: string;
  description: string;
}

export interface GameplanAction {
  category: string;
  items: string[];
}

export interface GameplanData {
  title: string;
  subtitle: string;
  leadershipCommitment: string;
  currentSituation: {
    challenge: string;
    target: string;
    timeline: string;
  };
  immediateActions: GameplanAction[];
  strategicInitiatives: GameplanAction[];
  successMetrics: {
    daily: string;
    weekly: string;
    monthly: string;
    ongoing: string;
  };
  preparedDate: string;
}

export interface DashboardData {
  opener: OpenerMetrics;
  monthRecap: MonthRecap;
  clientSegments: ClientSegment[];
  operationsHealth: OperationsHealth;
  callingMetrics: CallingMetrics;
  performanceReview: PerformanceReview;
  barbieOneThing: BarbieOneThing;
  currentChallenges: CurrentChallenge[];
  gameplan: GameplanData;
}
