import { DashboardData } from './types';

export const defaultDashboardData: DashboardData = {
  opener: {
    totalRevenue: '$2,450,000',
    ebitdaDollars: '$612,500',
    ebitdaPercent: '25%',
    retention: '92.5%',
    totalClients: 156,
    growthInMonth: '$125,000',
  },
  monthRecap: {
    toplineRevenue: '$215,000',
  },
  clientSegments: [
    {
      name: 'All Sapper Clients',
      color: 'purple',
      numberOfClients: 155,
      appointmentGoal: 3120,
      totalAppointments: 2856,
      percentToGoal: '91.5%',
      under50: 23,
      zeros: 4,
    },
    {
      name: 'Sapper Outbound Clients',
      color: 'blue',
      numberOfClients: 89,
      percentOfTotal: '57.4%',
      appointmentGoal: 1780,
      totalAppointments: 1623,
      percentToGoal: '91.2%',
      under50: 12,
      zeros: 2,
    },
    {
      name: 'Barbie Clients (>$4k)',
      color: 'pink',
      numberOfClients: 34,
      percentOfTotal: '21.9%',
      appointmentGoal: 680,
      totalAppointments: 658,
      percentToGoal: '96.8%',
      under50: 3,
      zeros: 0,
    },
  ],
  operationsHealth: {
    overallShowRate: '78.5%',
    sapperOutboundSDRs: 45,
    strategicSDRs: 12,
    totalPDMs: 8,
    sdrsUnder15Appts: 6,
  },
  callingMetrics: {
    contactRate: '32.5%',
    pitchRate: '68.2%',
    closeRate: '24.8%',
    showRate: '78.5%',
    qualityScore: '8.4',
    contractsOnPace: '94%',
    revenueClosed: '$425,000',
    averageDials: 150,
    sdrsUnder15Appts: 6,
  },
  performanceReview: {
    whatWentRight: [
      'Strong client retention above 91%',
      'Barbie clients exceeding appointment goals',
      'Quality scores trending upward',
    ],
    whereToImprove: [
      'Reduce under-performers (<50% to goal)',
      'Increase contact rate by 5%',
      'Better SDR training on objection handling',
    ],
  },
  barbieOneThing: {
    headline: 'Achieve 95%+ retention across all Barbie clients',
    progress: 65,
    whyThisMatters: 'High-value clients drive 40% of revenue with highest margins',
    owner: 'Sarah Mitchell',
    ownerInitial: 'S',
    successDefinition: 'Zero Barbie client churn in Q1, 100% appointment goal achievement',
  },
  currentChallenges: [
    {
      title: 'Slow Month Start',
      description: 'Started the month at 77% to goal, requiring aggressive catch-up strategy',
    },
    {
      title: 'SDR Consistency',
      description: '6 SDRs currently under 15 appointments - need targeted coaching',
    },
    {
      title: 'Contact Rate Below Target',
      description: 'Currently at 32.5%, aiming for 37.5% minimum',
    },
  ],
  gameplan: {
    title: 'SAPPER FULFILLMENT GAMEPLAN',
    subtitle: 'From 77% to 90% Goal Fulfillment',
    leadershipCommitment: '"Unapologetically focused on team growth, consistent daily performance, and client success. We\'re not just recovering - we\'re establishing new performance standards."',
    currentSituation: {
      challenge: 'Sapper at 77% to goal with a slow month start.',
      target: 'Achieve 90% goal fulfillment this month.',
      timeline: 'Immediate action with measurable daily progress.',
    },
    immediateActions: [
      {
        category: 'Leadership Presence and Energy',
        items: [
          'Moved to fulfillment floor full-time since Wednesday.',
          'Result: daily appointment progression Wed to Mon.',
          'Key insight: "Energy breeds appointments, not the other way around."',
        ],
      },
      {
        category: 'Daily Operations Structure',
        items: [
          '8 AM team huddles: daily advice, good news, clear expectations.',
          '"Amie Alcatraz" accountability: 10 to 15 minute daily sessions for underperformers (<2 appts/day).',
          'Purpose: consistent daily performance standards.',
        ],
      },
      {
        category: 'Strategic Personnel Moves',
        items: [
          'Tim Luzceky: transitioned to Sapper Outbound to set new hire standards (already hitting 3-4+ daily).',
          'Jake Columbia: direct 1:1 PSM with MAPS implementation plus daily appointment minimum.',
        ],
      },
    ],
    strategicInitiatives: [
      {
        category: 'High-Value Client Focus',
        items: [
          '"Barbie Clients": target 15 appointments daily (32% of client base = 42% of revenue).',
          'Impact: 46% of daily appointments focused on highest-paying clientele.',
        ],
      },
      {
        category: 'Training and Development',
        items: [
          'Personal shadow and training plan through January.',
          'Focus on intro optimization while Jake handles pitch and close improvement.',
          'Role establishment across floor by EOW (1/16).',
        ],
      },
      {
        category: 'Culture Transformation',
        items: [
          'Systematic relationship building with the SDR team.',
          'Performance accountability systems.',
          'Consistent daily execution standards.',
        ],
      },
    ],
    successMetrics: {
      daily: '15+ Barbie client appointments.',
      weekly: 'Progressive appointment increases.',
      monthly: '90% goal fulfillment achievement.',
      ongoing: 'Improved retention for future months.',
    },
    preparedDate: 'January 2026',
  },
};
