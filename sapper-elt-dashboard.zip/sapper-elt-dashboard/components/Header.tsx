'use client';

import { Edit, Monitor, FileDown } from 'lucide-react';

interface HeaderProps {
  onEditClick: () => void;
  sections: { id: string; label: string }[];
  activeSection: string;
  setActiveSection: (id: string) => void;
}

export default function Header({ onEditClick, sections, activeSection, setActiveSection }: HeaderProps) {
  const scrollToSection = (id: string) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handlePresent = () => {
    // Open in presentation mode (full screen)
    if (document.documentElement.requestFullscreen) {
      document.documentElement.requestFullscreen();
    }
  };

  const handleExportPDF = () => {
    window.print();
  };

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-40 no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Title */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-gradient-to-br from-sapper-navy to-sapper-blue rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">S</span>
              </div>
              <div className="ml-3">
                <h1 className="text-xl font-bold text-sapper-navy">Sapper ELT Dashboard</h1>
                <p className="text-xs text-slate-500">Fulfillment Performance</p>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <nav className="hidden lg:flex items-center space-x-1">
            {sections.slice(0, 5).map((section) => (
              <button
                key={section.id}
                onClick={() => scrollToSection(section.id)}
                className={`px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                  activeSection === section.id
                    ? 'bg-sapper-navy text-white'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {section.label}
              </button>
            ))}
          </nav>

          {/* Action Buttons */}
          <div className="flex items-center space-x-2">
            <button
              onClick={onEditClick}
              className="inline-flex items-center px-4 py-2 bg-sapper-blue text-white text-sm font-medium rounded-lg hover:bg-sapper-blue/90 transition-colors shadow-sm"
            >
              <Edit className="w-4 h-4 mr-2" />
              Edit
            </button>
            <button
              onClick={handlePresent}
              className="inline-flex items-center px-4 py-2 bg-white border border-slate-300 text-slate-700 text-sm font-medium rounded-lg hover:bg-slate-50 transition-colors"
            >
              <Monitor className="w-4 h-4 mr-2" />
              Present
            </button>
            <button
              onClick={handleExportPDF}
              className="inline-flex items-center px-4 py-2 bg-sapper-navy text-white text-sm font-medium rounded-lg hover:bg-sapper-navy-dark transition-colors"
            >
              <FileDown className="w-4 h-4 mr-2" />
              Export PDF
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
