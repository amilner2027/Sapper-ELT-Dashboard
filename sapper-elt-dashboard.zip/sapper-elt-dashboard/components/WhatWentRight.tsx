'use client';

import { PerformanceReview } from '@/lib/types';

interface WhatWentRightProps {
  data: PerformanceReview;
}

export default function WhatWentRight({ data }: WhatWentRightProps) {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      {/* Header */}
      <div className="px-6 py-4 border-b border-slate-200">
        <h2 className="text-xl font-bold text-slate-800">What Went Right / Improve</h2>
        <p className="text-sm text-slate-500 mt-1">Performance Review</p>
      </div>

      {/* Two Column Layout */}
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* What Went Right */}
          <div className="bg-slate-50 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">What Went Right</h3>
            <div className="space-y-3">
              {data.whatWentRight.map((item, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="w-7 h-7 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-semibold">
                    {index + 1}
                  </div>
                  <p className="text-slate-700 pt-0.5">{item}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Where Can We Improve */}
          <div className="bg-slate-50 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-slate-800 mb-4">Where Can We Improve</h3>
            <div className="space-y-3">
              {data.whereToImprove.map((item, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="w-7 h-7 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-semibold">
                    {index + 1}
                  </div>
                  <p className="text-slate-700 pt-0.5">{item}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
