'use client';

import { AlertTriangle } from 'lucide-react';
import { CurrentChallenge } from '@/lib/types';

interface CurrentChallengesProps {
  challenges: CurrentChallenge[];
}

export default function CurrentChallenges({ challenges }: CurrentChallengesProps) {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-amber-500 to-orange-500 px-6 py-3">
        <h2 className="text-white font-semibold text-lg flex items-center">
          <AlertTriangle className="w-5 h-5 mr-2" />
          Current State: Challenges We're Battling
        </h2>
      </div>

      {/* Challenges Grid */}
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {challenges.map((challenge, index) => (
            <div
              key={index}
              className="bg-amber-50 border border-amber-200 rounded-xl p-5 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start space-x-3">
                <div className="w-8 h-8 bg-amber-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <span className="text-white font-bold text-sm">{index + 1}</span>
                </div>
                <div>
                  <h3 className="font-semibold text-slate-800 mb-1">{challenge.title}</h3>
                  <p className="text-sm text-slate-600">{challenge.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
