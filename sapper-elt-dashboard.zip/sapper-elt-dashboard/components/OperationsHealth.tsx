'use client';

import { OperationsHealth as OperationsHealthType } from '@/lib/types';

interface OperationsHealthProps {
  data: OperationsHealthType;
}

export default function OperationsHealth({ data }: OperationsHealthProps) {
  const metrics = [
    {
      label: 'OVERALL SHOW RATE',
      value: data.overallShowRate,
      color: 'text-sapper-blue',
    },
    {
      label: 'SAPPER OUTBOUND SDRS',
      value: data.sapperOutboundSDRs,
      color: 'text-slate-800',
    },
    {
      label: 'STRATEGIC SDRS',
      value: data.strategicSDRs,
      color: 'text-slate-800',
    },
    {
      label: 'TOTAL PDMS',
      value: data.totalPDMs,
      color: 'text-slate-800',
    },
    {
      label: 'SDRS UNDER 15 APPTS',
      value: data.sdrsUnder15Appts,
      color: 'text-red-500',
    },
  ];

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      {/* Header */}
      <div className="px-6 py-3 border-b border-slate-100">
        <h2 className="text-lg font-semibold text-slate-600">Operations Health</h2>
      </div>

      {/* Metrics Row */}
      <div className="p-6">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
          {metrics.map((metric, index) => (
            <div key={index} className="text-center">
              <p className="text-xs font-medium text-slate-500 uppercase tracking-wider mb-2">
                {metric.label}
              </p>
              <p className={`text-3xl font-bold ${metric.color}`}>
                {metric.value}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
