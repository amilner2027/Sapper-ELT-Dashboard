'use client';

import { ClientSegment } from '@/lib/types';

interface ClientBreakdownProps {
  segments: ClientSegment[];
}

const colorClasses: Record<string, { header: string; text: string; accent: string }> = {
  purple: {
    header: 'bg-gradient-to-r from-purple-600 to-purple-500',
    text: 'text-purple-600',
    accent: 'border-l-purple-500',
  },
  blue: {
    header: 'bg-gradient-to-r from-sky-500 to-cyan-400',
    text: 'text-sky-600',
    accent: 'border-l-sky-500',
  },
  pink: {
    header: 'bg-gradient-to-r from-pink-500 to-pink-400',
    text: 'text-pink-600',
    accent: 'border-l-pink-500',
  },
};

export default function ClientBreakdown({ segments }: ClientBreakdownProps) {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      {/* Header */}
      <div className="px-6 py-4 border-b border-slate-200">
        <h2 className="text-xl font-bold text-slate-800">Client Breakdown & Fulfillment</h2>
        <p className="text-sm text-slate-500 mt-1">Client Performance by Segment</p>
      </div>

      {/* Segments Grid */}
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {segments.map((segment, index) => {
            const colors = colorClasses[segment.color] || colorClasses.purple;
            return (
              <div
                key={index}
                className={`rounded-xl overflow-hidden shadow-sm border border-slate-200 metric-card`}
              >
                {/* Segment Header */}
                <div className={`${colors.header} px-4 py-3`}>
                  <h3 className="text-white font-semibold">{segment.name}</h3>
                </div>

                {/* Segment Stats */}
                <div className={`p-4 space-y-3 border-l-4 ${colors.accent}`}>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-500">Number of Clients</span>
                    <span className="font-bold text-slate-800">{segment.numberOfClients}</span>
                  </div>

                  {segment.percentOfTotal && (
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-slate-500">% of Total Clients</span>
                      <span className="font-bold text-slate-800">{segment.percentOfTotal}</span>
                    </div>
                  )}

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-500">Appointment Goal</span>
                    <span className="font-bold text-slate-800">{segment.appointmentGoal.toLocaleString()}</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-500">Total Appointments</span>
                    <span className={`font-bold ${colors.text}`}>{segment.totalAppointments.toLocaleString()}</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-500">Percent to Goal</span>
                    <span className={`font-bold text-lg ${colors.text}`}>{segment.percentToGoal}</span>
                  </div>

                  <div className="pt-2 border-t border-slate-100">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-slate-500">Under 50%</span>
                      <span className="font-semibold text-slate-700">{segment.under50}</span>
                    </div>
                    <div className="flex justify-between items-center mt-1">
                      <span className="text-sm text-slate-500">Zeros</span>
                      <span className="font-semibold text-slate-700">{segment.zeros}</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
