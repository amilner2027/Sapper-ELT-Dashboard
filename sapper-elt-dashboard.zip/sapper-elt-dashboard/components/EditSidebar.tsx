'use client';

import { X, RotateCcw } from 'lucide-react';
import { DashboardData } from '@/lib/types';

interface EditSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  data: DashboardData;
  onUpdate: (data: Partial<DashboardData>) => void;
  onReset: () => void;
}

export default function EditSidebar({ isOpen, onClose, data, onUpdate, onReset }: EditSidebarProps) {
  const updateOpener = (field: string, value: string | number) => {
    onUpdate({
      opener: { ...data.opener, [field]: value },
    });
  };

  const updateCallingMetrics = (field: string, value: string | number) => {
    onUpdate({
      callingMetrics: { ...data.callingMetrics, [field]: value },
    });
  };

  const updateOperationsHealth = (field: string, value: string | number) => {
    onUpdate({
      operationsHealth: { ...data.operationsHealth, [field]: value },
    });
  };

  const updateBarbieOneThing = (field: string, value: string | number) => {
    onUpdate({
      barbieOneThing: { ...data.barbieOneThing, [field]: value },
    });
  };

  const updateClientSegment = (index: number, field: string, value: string | number) => {
    const updatedSegments = [...data.clientSegments];
    updatedSegments[index] = { ...updatedSegments[index], [field]: value };
    onUpdate({ clientSegments: updatedSegments });
  };

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div
        className={`fixed right-0 top-0 h-full w-96 bg-white shadow-2xl z-50 transform transition-transform duration-300 ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <h2 className="text-lg font-bold text-slate-800">Edit Inputs</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-slate-600" />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto h-[calc(100%-140px)] p-6">
          {/* OPENER Section */}
          <div className="mb-8">
            <h3 className="text-sm font-bold text-sapper-blue uppercase tracking-wider mb-4">
              Opener
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-slate-600 mb-1">Total Revenue</label>
                <input
                  type="text"
                  value={data.opener.totalRevenue}
                  onChange={(e) => updateOpener('totalRevenue', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">EBITDA ($)</label>
                <input
                  type="text"
                  value={data.opener.ebitdaDollars}
                  onChange={(e) => updateOpener('ebitdaDollars', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">EBITDA (%)</label>
                <input
                  type="text"
                  value={data.opener.ebitdaPercent}
                  onChange={(e) => updateOpener('ebitdaPercent', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">Retention (%)</label>
                <input
                  type="text"
                  value={data.opener.retention}
                  onChange={(e) => updateOpener('retention', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">Total Clients</label>
                <input
                  type="number"
                  value={data.opener.totalClients}
                  onChange={(e) => updateOpener('totalClients', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">Growth in Month</label>
                <input
                  type="text"
                  value={data.opener.growthInMonth}
                  onChange={(e) => updateOpener('growthInMonth', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>
            </div>
          </div>

          {/* Month Recap Section */}
          <div className="mb-8">
            <h3 className="text-sm font-bold text-sapper-blue uppercase tracking-wider mb-4">
              Month Recap
            </h3>
            
            <div>
              <label className="block text-sm text-slate-600 mb-1">Topline Revenue</label>
              <input
                type="text"
                value={data.monthRecap.toplineRevenue}
                onChange={(e) => onUpdate({ monthRecap: { ...data.monthRecap, toplineRevenue: e.target.value } })}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
              />
            </div>
          </div>

          {/* Operations Health Section */}
          <div className="mb-8">
            <h3 className="text-sm font-bold text-sapper-blue uppercase tracking-wider mb-4">
              Operations Health
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-slate-600 mb-1">Overall Show Rate</label>
                <input
                  type="text"
                  value={data.operationsHealth.overallShowRate}
                  onChange={(e) => updateOperationsHealth('overallShowRate', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">Sapper Outbound SDRs</label>
                <input
                  type="number"
                  value={data.operationsHealth.sapperOutboundSDRs}
                  onChange={(e) => updateOperationsHealth('sapperOutboundSDRs', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">Strategic SDRs</label>
                <input
                  type="number"
                  value={data.operationsHealth.strategicSDRs}
                  onChange={(e) => updateOperationsHealth('strategicSDRs', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">Total PDMs</label>
                <input
                  type="number"
                  value={data.operationsHealth.totalPDMs}
                  onChange={(e) => updateOperationsHealth('totalPDMs', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">SDRs Under 15 Appts</label>
                <input
                  type="number"
                  value={data.operationsHealth.sdrsUnder15Appts}
                  onChange={(e) => updateOperationsHealth('sdrsUnder15Appts', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>
            </div>
          </div>

          {/* Calling Metrics Section */}
          <div className="mb-8">
            <h3 className="text-sm font-bold text-sapper-blue uppercase tracking-wider mb-4">
              Calling Metrics
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-slate-600 mb-1">Contact Rate</label>
                <input
                  type="text"
                  value={data.callingMetrics.contactRate}
                  onChange={(e) => updateCallingMetrics('contactRate', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">Pitch Rate</label>
                <input
                  type="text"
                  value={data.callingMetrics.pitchRate}
                  onChange={(e) => updateCallingMetrics('pitchRate', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">Close Rate</label>
                <input
                  type="text"
                  value={data.callingMetrics.closeRate}
                  onChange={(e) => updateCallingMetrics('closeRate', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">Show Rate</label>
                <input
                  type="text"
                  value={data.callingMetrics.showRate}
                  onChange={(e) => updateCallingMetrics('showRate', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">Quality Score</label>
                <input
                  type="text"
                  value={data.callingMetrics.qualityScore}
                  onChange={(e) => updateCallingMetrics('qualityScore', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">Contracts on Pace</label>
                <input
                  type="text"
                  value={data.callingMetrics.contractsOnPace}
                  onChange={(e) => updateCallingMetrics('contractsOnPace', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">Revenue Closed</label>
                <input
                  type="text"
                  value={data.callingMetrics.revenueClosed}
                  onChange={(e) => updateCallingMetrics('revenueClosed', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">Average Dials</label>
                <input
                  type="number"
                  value={data.callingMetrics.averageDials}
                  onChange={(e) => updateCallingMetrics('averageDials', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                />
              </div>
            </div>
          </div>

          {/* One Thing Section */}
          <div className="mb-8">
            <h3 className="text-sm font-bold text-barbie-pink uppercase tracking-wider mb-4">
              One Thing - Barbie Focus
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-slate-600 mb-1">Headline</label>
                <input
                  type="text"
                  value={data.barbieOneThing.headline}
                  onChange={(e) => updateBarbieOneThing('headline', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-barbie-pink focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">Progress (%)</label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={data.barbieOneThing.progress}
                  onChange={(e) => updateBarbieOneThing('progress', parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-barbie-pink focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">Why This Matters</label>
                <textarea
                  value={data.barbieOneThing.whyThisMatters}
                  onChange={(e) => updateBarbieOneThing('whyThisMatters', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-barbie-pink focus:border-transparent"
                  rows={2}
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">Owner</label>
                <input
                  type="text"
                  value={data.barbieOneThing.owner}
                  onChange={(e) => updateBarbieOneThing('owner', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-barbie-pink focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm text-slate-600 mb-1">Success Definition</label>
                <textarea
                  value={data.barbieOneThing.successDefinition}
                  onChange={(e) => updateBarbieOneThing('successDefinition', e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-barbie-pink focus:border-transparent"
                  rows={2}
                />
              </div>
            </div>
          </div>

          {/* Client Segments */}
          <div className="mb-8">
            <h3 className="text-sm font-bold text-sapper-blue uppercase tracking-wider mb-4">
              Client Segments
            </h3>
            
            {data.clientSegments.map((segment, index) => (
              <div key={index} className="mb-6 p-4 bg-slate-50 rounded-lg">
                <h4 className="font-semibold text-slate-700 mb-3">{segment.name}</h4>
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs text-slate-500 mb-1">Number of Clients</label>
                    <input
                      type="number"
                      value={segment.numberOfClients}
                      onChange={(e) => updateClientSegment(index, 'numberOfClients', parseInt(e.target.value) || 0)}
                      className="w-full px-2 py-1.5 text-sm border border-slate-300 rounded focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500 mb-1">Appointment Goal</label>
                    <input
                      type="number"
                      value={segment.appointmentGoal}
                      onChange={(e) => updateClientSegment(index, 'appointmentGoal', parseInt(e.target.value) || 0)}
                      className="w-full px-2 py-1.5 text-sm border border-slate-300 rounded focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500 mb-1">Total Appointments</label>
                    <input
                      type="number"
                      value={segment.totalAppointments}
                      onChange={(e) => updateClientSegment(index, 'totalAppointments', parseInt(e.target.value) || 0)}
                      className="w-full px-2 py-1.5 text-sm border border-slate-300 rounded focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-500 mb-1">Percent to Goal</label>
                    <input
                      type="text"
                      value={segment.percentToGoal}
                      onChange={(e) => updateClientSegment(index, 'percentToGoal', e.target.value)}
                      className="w-full px-2 py-1.5 text-sm border border-slate-300 rounded focus:ring-2 focus:ring-sapper-blue focus:border-transparent"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="absolute bottom-0 left-0 right-0 p-4 bg-white border-t border-slate-200">
          <button
            onClick={onReset}
            className="w-full py-3 px-4 border-2 border-red-300 text-red-600 font-medium rounded-lg hover:bg-red-50 transition-colors flex items-center justify-center"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset All to Defaults
          </button>
        </div>
      </div>
    </>
  );
}
