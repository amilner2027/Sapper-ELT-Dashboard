'use client';

import { BarbieOneThing as BarbieOneThingType } from '@/lib/types';

interface BarbieOneThingProps {
  data: BarbieOneThingType;
}

export default function BarbieOneThing({ data }: BarbieOneThingProps) {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-barbie-pink to-barbie-pink-dark px-6 py-3">
        <h2 className="text-white font-semibold text-lg">One Thing — Sapper Barbies</h2>
      </div>

      {/* Content */}
      <div className="p-8">
        {/* Main Headline */}
        <div className="bg-barbie-pink-light/20 border border-barbie-pink/20 rounded-2xl p-8 mb-8 text-center">
          <h3 className="text-3xl md:text-4xl font-bold italic text-barbie-pink">
            {data.headline}
          </h3>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-slate-600">Progress</span>
            <span className="text-lg font-bold text-sapper-blue">{data.progress}%</span>
          </div>
          <div className="h-4 bg-slate-200 rounded-full overflow-hidden">
            <div
              className="h-full rounded-full progress-animated"
              style={{
                width: `${data.progress}%`,
                background: 'linear-gradient(90deg, #3B82F6 0%, #EC4899 100%)',
              }}
            />
          </div>
        </div>

        {/* Info Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {/* Why This Matters */}
          <div className="bg-slate-50 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-slate-800 mb-3">Why This Matters</h4>
            <p className="text-slate-600">{data.whyThisMatters}</p>
          </div>

          {/* Owner */}
          <div className="bg-slate-50 rounded-xl p-6">
            <h4 className="text-lg font-semibold text-slate-800 mb-3">Owner</h4>
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-barbie-pink rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">{data.ownerInitial}</span>
              </div>
              <span className="text-lg font-medium text-slate-800">{data.owner}</span>
            </div>
          </div>
        </div>

        {/* Success Definition */}
        <div className="bg-slate-50 rounded-xl p-6">
          <h4 className="text-lg font-semibold text-slate-800 mb-3">Success Definition</h4>
          <p className="text-slate-600">{data.successDefinition}</p>
        </div>
      </div>
    </div>
  );
}
