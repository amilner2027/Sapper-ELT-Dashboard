'use client';

export default function BarbiePrinciple() {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-barbie-pink to-barbie-pink-dark px-6 py-3">
        <h2 className="text-white font-semibold text-lg">Barbie Principle</h2>
      </div>

      {/* Main Content */}
      <div className="p-8 text-center">
        {/* Main Quote */}
        <h3 className="text-4xl md:text-5xl font-bold italic text-barbie-pink mb-6">
          "Put the pink dress on<br />Barbie. Always."
        </h3>

        {/* Description */}
        <p className="text-lg text-slate-600 max-w-2xl mx-auto mb-8">
          Putting our best resources on our highest-paying clients to deliver
          exceptional service and maximize retention.
        </p>

        {/* Barbie Images */}
        <div className="flex items-center justify-center space-x-8 mb-8">
          {/* Silhouette */}
          <div className="w-32 h-40 bg-slate-100 rounded-lg flex items-center justify-center shadow-sm">
            <svg viewBox="0 0 100 140" className="w-24 h-32">
              <path
                d="M50 10 C30 10 25 30 25 45 C25 55 30 65 35 70 L30 85 C25 90 20 100 25 110 L35 130 L40 130 L45 110 L50 100 L55 110 L60 130 L65 130 L75 110 C80 100 75 90 70 85 L65 70 C70 65 75 55 75 45 C75 30 70 10 50 10"
                fill="black"
              />
              <ellipse cx="50" cy="25" rx="18" ry="20" fill="black" />
              <path
                d="M32 15 Q25 5 30 0 Q40 5 50 5 Q60 5 70 0 Q75 5 68 15"
                fill="black"
              />
            </svg>
          </div>

          {/* Divider */}
          <div className="w-px h-32 bg-slate-300"></div>

          {/* Pink Dress */}
          <div className="w-32 h-40 bg-slate-100 rounded-lg flex items-center justify-center shadow-sm overflow-hidden">
            <svg viewBox="0 0 100 140" className="w-28 h-36">
              {/* Dress shape */}
              <path
                d="M50 20 L35 35 L25 130 L75 130 L65 35 Z"
                fill="#FF69B4"
                stroke="#DB7093"
                strokeWidth="1"
              />
              {/* Bodice detail */}
              <path
                d="M40 25 L50 20 L60 25 L55 45 L45 45 Z"
                fill="#FF1493"
              />
              {/* Sparkles/decorations */}
              <circle cx="45" cy="60" r="2" fill="#FFD700" />
              <circle cx="55" cy="75" r="2" fill="#FFD700" />
              <circle cx="42" cy="90" r="2" fill="#FFD700" />
              <circle cx="58" cy="105" r="2" fill="#FFD700" />
              <circle cx="50" cy="85" r="1.5" fill="#FFD700" />
              <circle cx="48" cy="115" r="2" fill="#FFD700" />
              {/* Ruffle details */}
              <path
                d="M30 100 Q35 95 40 100 Q45 105 50 100 Q55 95 60 100 Q65 105 70 100"
                fill="none"
                stroke="#DB7093"
                strokeWidth="1"
              />
              <path
                d="M28 115 Q35 110 42 115 Q50 120 58 115 Q65 110 72 115"
                fill="none"
                stroke="#DB7093"
                strokeWidth="1"
              />
            </svg>
          </div>
        </div>

        {/* Key Message */}
        <div className="inline-block bg-barbie-pink-light/30 border border-barbie-pink/20 rounded-xl px-8 py-4">
          <p className="text-barbie-pink font-semibold text-lg">
            High-value clients = High-touch service
          </p>
        </div>
      </div>
    </div>
  );
}
