'use client';

import { CallingMetrics as CallingMetricsType } from '@/lib/types';

interface CallingMetricsProps {
  data: CallingMetricsType;
}

type ThresholdColor = 'green' | 'yellow' | 'red' | 'blue';

function getThresholdColor(value: string, type: 'percent' | 'score' | 'currency' | 'number'): ThresholdColor {
  // Parse the value
  let numValue: number;
  if (type === 'percent') {
    numValue = parseFloat(value.replace('%', ''));
  } else if (type === 'score') {
    numValue = parseFloat(value);
  } else if (type === 'currency') {
    numValue = parseFloat(value.replace(/[$,]/g, ''));
  } else {
    numValue = parseInt(value);
  }

  // Thresholds: Green = 80%+, Yellow = 60-79%, Red = <60%
  if (type === 'percent' || type === 'score') {
    if (numValue >= 80) return 'green';
    if (numValue >= 60) return 'yellow';
    return 'red';
  }
  
  return 'blue';
}

const colorClasses: Record<ThresholdColor, string> = {
  green: 'border-l-green-500',
  yellow: 'border-l-yellow-500',
  red: 'border-l-red-500',
  blue: 'border-l-sapper-blue',
};

export default function CallingMetrics({ data }: CallingMetricsProps) {
  const metrics = [
    { label: 'CONTACT RATE', value: data.contactRate, type: 'percent' as const },
    { label: 'PITCH RATE', value: data.pitchRate, type: 'percent' as const },
    { label: 'CLOSE RATE', value: data.closeRate, type: 'percent' as const },
    { label: 'SHOW RATE', value: data.showRate, type: 'percent' as const },
    { label: 'QUALITY SCORE', value: data.qualityScore, type: 'score' as const },
    { label: 'CONTRACTS ON PACE', value: data.contractsOnPace, type: 'percent' as const },
    { label: 'REVENUE CLOSED FOR', value: data.revenueClosed, type: 'currency' as const },
    { label: 'AVERAGE DIALS', value: data.averageDials.toString(), type: 'number' as const },
    { label: '# SDRS UNDER 15 APPTS', value: data.sdrsUnder15Appts.toString(), type: 'number' as const, isWarning: true },
  ];

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      {/* Header */}
      <div className="px-6 py-4 border-b border-slate-200">
        <h2 className="text-xl font-bold text-slate-800">Calling Metrics (Sapper Only)</h2>
        <p className="text-sm text-slate-500 mt-1">
          Sapper Outbound Calling Performance
        </p>
        <p className="text-xs text-slate-400 mt-1">
          Thresholds: Green = 80%+, Yellow = 60-79%, Red = &lt;60%
        </p>
      </div>

      {/* Metrics Grid */}
      <div className="p-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {metrics.slice(0, 8).map((metric, index) => {
            const thresholdColor = getThresholdColor(metric.value, metric.type);
            return (
              <div
                key={index}
                className={`bg-white rounded-xl border border-slate-200 p-4 border-l-4 ${colorClasses[thresholdColor]} metric-card`}
              >
                <p className="text-xs font-medium text-slate-500 uppercase tracking-wider mb-2">
                  {metric.label}
                </p>
                <p className="text-3xl font-bold text-slate-800">
                  {metric.value}
                </p>
              </div>
            );
          })}
        </div>

        {/* Warning metric */}
        <div className="mt-4">
          <div className="bg-white rounded-xl border border-slate-200 p-4 border-l-4 border-l-red-500 max-w-xs metric-card">
            <p className="text-xs font-medium text-slate-500 uppercase tracking-wider mb-2">
              # SDRS UNDER 15 APPTS
            </p>
            <p className="text-3xl font-bold text-red-500">
              {data.sdrsUnder15Appts}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
