'use client';

import { useState } from 'react';
import { DashboardData } from '@/lib/types';
import { defaultDashboardData } from '@/lib/defaultData';
import Header from '@/components/Header';
import EditSidebar from '@/components/EditSidebar';
import BarbiePrinciple from '@/components/BarbiePrinciple';
import CurrentChallenges from '@/components/CurrentChallenges';
import ClientBreakdown from '@/components/ClientBreakdown';
import OperationsHealth from '@/components/OperationsHealth';
import CallingMetrics from '@/components/CallingMetrics';
import WhatWentRight from '@/components/WhatWentRight';
import BarbieOneThing from '@/components/BarbieOneThing';
import Gameplan from '@/components/Gameplan';

export default function Dashboard() {
  const [data, setData] = useState<DashboardData>(defaultDashboardData);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<string>('barbie-principle');

  const handleDataUpdate = (newData: Partial<DashboardData>) => {
    setData(prev => ({ ...prev, ...newData }));
  };

  const resetToDefaults = () => {
    setData(defaultDashboardData);
  };

  const sections = [
    { id: 'barbie-principle', label: 'Barbie Principle' },
    { id: 'current-challenges', label: 'Current Challenges' },
    { id: 'client-breakdown', label: 'Client Breakdown' },
    { id: 'operations-health', label: 'Operations Health' },
    { id: 'calling-metrics', label: 'Calling Metrics' },
    { id: 'what-went-right', label: 'What Went Right' },
    { id: 'one-thing', label: 'One Thing Focus' },
    { id: 'gameplan', label: 'Execution Gameplan' },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <Header 
        onEditClick={() => setIsEditOpen(true)} 
        sections={sections}
        activeSection={activeSection}
        setActiveSection={setActiveSection}
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Barbie Principle Section */}
        <section id="barbie-principle" className="mb-12">
          <BarbiePrinciple />
        </section>

        {/* Current Challenges Section */}
        <section id="current-challenges" className="mb-12">
          <CurrentChallenges challenges={data.currentChallenges} />
        </section>

        {/* Client Breakdown & Fulfillment */}
        <section id="client-breakdown" className="mb-12">
          <ClientBreakdown segments={data.clientSegments} />
        </section>

        {/* Operations Health */}
        <section id="operations-health" className="mb-12">
          <OperationsHealth data={data.operationsHealth} />
        </section>

        {/* Calling Metrics */}
        <section id="calling-metrics" className="mb-12">
          <CallingMetrics data={data.callingMetrics} />
        </section>

        {/* What Went Right / Improve */}
        <section id="what-went-right" className="mb-12">
          <WhatWentRight data={data.performanceReview} />
        </section>

        {/* One Thing - Barbie Focus */}
        <section id="one-thing" className="mb-12">
          <BarbieOneThing data={data.barbieOneThing} />
        </section>

        {/* Gameplan Section */}
        <section id="gameplan" className="mb-12">
          <Gameplan data={data.gameplan} />
        </section>
      </main>

      {/* Edit Sidebar */}
      <EditSidebar 
        isOpen={isEditOpen}
        onClose={() => setIsEditOpen(false)}
        data={data}
        onUpdate={handleDataUpdate}
        onReset={resetToDefaults}
      />
    </div>
  );
}
