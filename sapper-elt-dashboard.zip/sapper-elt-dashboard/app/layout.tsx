import './globals.css'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Sapper ELT Dashboard',
  description: 'Executive Leadership Team Fulfillment Dashboard',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="bg-slate-50 min-h-screen">
        {children}
      </body>
    </html>
  )
}
